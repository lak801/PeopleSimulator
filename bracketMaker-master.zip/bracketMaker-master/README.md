# bracketMaker
Created with CodeSandbox

I developed this tournament bracket as a learning project for ReactJS. It is not professional, but it does get the job done of course!
I included comments that somewhat explain the thought process and reasonings for certain bits of code that hopefully will help!
Thank you for reading!
